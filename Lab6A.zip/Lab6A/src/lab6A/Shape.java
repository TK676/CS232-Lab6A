package lab6A;


public abstract class Shape {
    public abstract double area();
}
